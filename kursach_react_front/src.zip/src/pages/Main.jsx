export default function Main() {
    return <div>Main page (Главная)</div>;
}
